import torch
from diffusers import AutoPipelineForText2Image
from PIL import Image
import os

def generate_manhwa_image(prompt: str, output_path: str, model_id: str = "runwayml/stable-diffusion-v1-5", style_prompt: str = "manhwa style, webtoon, detailed illustration, vibrant colors", negative_prompt: str = "photorealistic, 3d render, blurry, low quality, text, signature, watermark, deformed, bad anatomy"):
    """Generates an image based on a prompt using a diffusion model and saves it.
    Handles prompt truncation if the combined prompt exceeds model limits.
    """
    print(f"Generating image for base prompt: ")

    # Combine base prompt and style prompt
    full_prompt = f"{prompt}, {style_prompt}"
    print(f"  Initial full prompt: {full_prompt}")
    print(f"  Negative prompt: {negative_prompt}")
    print(f"  Model ID: {model_id}")

    try:
        # Determine device
        device = "cuda" if torch.cuda.is_available() else "cpu"
        torch_dtype = torch.float32
        print(f"Using device: {device} with dtype: {torch_dtype}")

        # Load the pipeline
        print("Loading diffusion pipeline...")
        pipe = AutoPipelineForText2Image.from_pretrained(
            model_id,
            torch_dtype=torch_dtype,
            use_safetensors=True
        )
        pipe.to(device)
        print("Pipeline loaded successfully.")

        # --- Prompt Truncation Logic ---
        # Get the tokenizer and max length
        tokenizer = pipe.tokenizer
        max_length = tokenizer.model_max_length
        print(f"Tokenizer max length: {max_length}")

        # Tokenize the full prompt
        input_ids = tokenizer(full_prompt, return_tensors="pt").input_ids

        # Check if truncation is needed
        if input_ids.shape[-1] > max_length:
            print(f"Warning: Prompt length ({input_ids.shape[-1]}) exceeds max length ({max_length}). Truncating.")
            # Truncate the input_ids
            truncated_ids = input_ids[:, :max_length]
            # Decode back to text, skipping special tokens
            truncated_prompt = tokenizer.decode(truncated_ids[0], skip_special_tokens=True)
            print(f"  Truncated prompt: {truncated_prompt}")
            final_prompt = truncated_prompt
        else:
            final_prompt = full_prompt
            print("Prompt length is within limits.")
        # --- End Prompt Truncation Logic ---

        # Generate the image using the potentially truncated prompt
        print("Generating image...")
        image = pipe(
            prompt=final_prompt,
            negative_prompt=negative_prompt,
            guidance_scale=7.5,
            num_inference_steps=25
        ).images[0]
        print("Image generated.")

        # Ensure output directory exists
        output_dir = os.path.dirname(output_path)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        # Save the image
        image.save(output_path)
        print(f"Image saved to {output_path}")
        return output_path

    except Exception as e:
        print(f"Error during image generation: {e}")
        if 'pipe' in locals():
            del pipe
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        return None

# Example Usage (remains the same for testing the module itself)
if __name__ == "__main__":
    print("Starting image generation test with Stable Diffusion v1.5...")
    test_prompt = "A brave young boy named Ali exploring a dark forest, fantasy setting"
    output_file = "/home/ubuntu/generated_image_test_v1-5.png"

    if os.path.exists(output_file):
        os.remove(output_file)
        print(f"Removed previous test file: {output_file}")

    generated_file = generate_manhwa_image(test_prompt, output_file)

    if generated_file and os.path.exists(generated_file):
        print(f"Test image generation successful: {generated_file}")
    else:
        print("Test image generation failed.")

