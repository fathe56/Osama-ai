import os
import story_processor
import image_generator
import re
import shutil # Import shutil for directory removal

def create_prompt_from_scene(scene_analysis):
    """Creates a concise prompt for image generation from scene analysis, aiming for < 77 tokens."""
    text = scene_analysis["text"]
    
    # Remove dialogue for the visual prompt
    prompt = re.sub(r'["“”](.*?)["“”]', '', text).strip()
    prompt = re.sub(r'\s+', ' ', prompt) # Replace multiple spaces with single space
    
    # If prompt becomes empty after removing dialogue, use original text
    if not prompt:
        prompt = text

    # Aggressively shorten the prompt to fit within token limits
    # Target ~50-60 words max as a rough estimate for < 77 tokens
    words = prompt.split()
    max_words = 50 
    if len(words) > max_words:
        prompt = " ".join(words[:max_words]) + "..."

    # Add character info if available (placeholder)
    # if scene_analysis["characters"]:
    #     prompt += f", characters: {", ".join(scene_analysis["characters"])}"

    # Add context like 'fantasy setting' if needed
    # prompt += ", fantasy setting" 

    # Final check for empty prompt
    if not prompt:
        return "manhwa scene" # Default prompt if everything else fails

    return prompt

def convert_story_to_manhwa(story_text: str, output_dir: str):
    """Processes a story and generates manhwa-style images for each scene."""
    print(f"Starting conversion process for story. Output directory: {output_dir}")
    # Ensure output directory exists, create if not
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. Process the story
    print("\nStep 1: Processing story text...")
    # Ensure NLTK data is downloaded before processing
    story_processor.download_nltk_data()
    analyzed_story = story_processor.process_story(story_text)
    if not analyzed_story:
        print("Error: Story processing failed.")
        return
    print(f"Story processed into {len(analyzed_story)} scenes.")

    # 2. Generate image for each scene
    print("\nStep 2: Generating images for each scene...")
    generated_image_paths = []
    for i, scene in enumerate(analyzed_story):
        scene_num = i + 1
        print(f"\n--- Generating image for Scene {scene_num}/{len(analyzed_story)} ---")
        
        # Create prompt from scene analysis
        base_prompt = create_prompt_from_scene(scene)
        if not base_prompt:
            print(f"Warning: Could not generate prompt for Scene {scene_num}. Skipping.")
            continue
            
        # Define output path
        output_filename = f"scene_{scene_num:03d}.png"
        output_path = os.path.join(output_dir, output_filename)
        
        # Generate image using the function from image_generator.py
        # The style prompt is added within generate_manhwa_image
        image_path = image_generator.generate_manhwa_image(
            prompt=base_prompt, 
            output_path=output_path,
            model_id="runwayml/stable-diffusion-v1-5" # Explicitly use v1.5
        )
        
        if image_path:
            generated_image_paths.append(image_path)
            print(f"Successfully generated image for Scene {scene_num}.")
        else:
            print(f"Failed to generate image for Scene {scene_num}.")
            # Continue to the next scene even if one fails
            continue 

    print("\nConversion process finished.")
    print(f"Generated {len(generated_image_paths)} images in {output_dir}")
    return generated_image_paths

# Example Usage
if __name__ == "__main__":
    sample_story = """
كان يا مكان في قديم الزمان، قرية صغيرة تقع بجانب غابة كثيفة. عاش في القرية فتى شجاع اسمه "علي". كان علي يحب استكشاف الغابة.

في أحد الأيام، بينما كان علي يتجول في الغابة، سمع صوتًا غريبًا. قال لنفسه: "ما هذا الصوت؟". تبع علي الصوت بحذر حتى وصل إلى كهف مظلم.

"هل من أحد هنا؟" صاح علي بصوت مرتفع. خرج من الكهف تنين صغير لطيف بدا خائفًا. ابتسم علي وقال: "لا تخف أيها الصغير، أنا صديق".
    """
    output_directory = "/home/ubuntu/manhwa_output"
    
    # Clean up previous output directory if it exists
    if os.path.exists(output_directory):
        try:
            shutil.rmtree(output_directory)
            print(f"Removed previous output directory: {output_directory}")
        except OSError as e:
            print(f"Error removing directory {output_directory}: {e}")
        
    convert_story_to_manhwa(sample_story, output_directory)

