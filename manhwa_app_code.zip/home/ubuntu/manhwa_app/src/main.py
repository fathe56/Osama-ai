import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, request, render_template, send_from_directory, url_for
import main_converter # Import the main conversion script
import uuid
import shutil

app = Flask(__name__, static_folder=".", static_url_path="")
app.config["SECRET_KEY"] = os.urandom(24)

# Define the base directory for outputs within the static folder
OUTPUT_BASE_DIR = os.path.join(app.static_folder, "outputs")
os.makedirs(OUTPUT_BASE_DIR, exist_ok=True)

@app.route("/")
def index():
    """Renders the main page with the story input form."""
    return render_template("index.html")

@app.route("/convert", methods=["POST"])
def convert():
    """Handles story submission, runs conversion, and displays results."""
    story_text = request.form.get("story_text")
    if not story_text:
        return "Error: No story text provided.", 400

    # Create a unique directory for this conversion's output images within the static outputs folder
    conversion_id = str(uuid.uuid4())
    output_dir_relative = os.path.join("outputs", conversion_id)
    output_dir_absolute = os.path.join(app.static_folder, output_dir_relative)
    os.makedirs(output_dir_absolute, exist_ok=True)

    print(f"Starting conversion for ID: {conversion_id}")
    print(f"Absolute output dir: {output_dir_absolute}")

    try:
        # Run the conversion process (this will block and might take a long time)
        # Note: For production, use background tasks (Celery, RQ) to avoid timeouts
        generated_image_paths_absolute = main_converter.convert_story_to_manhwa(story_text, output_dir_absolute)
        
        if not generated_image_paths_absolute:
             print(f"Conversion {conversion_id} resulted in no images.")
             # Optionally, clean up the empty directory
             # shutil.rmtree(output_dir_absolute)
             return render_template("results.html", error="Failed to generate any images.", image_urls=[])

        # Generate relative URLs for the template
        image_urls = []
        for img_path_abs in generated_image_paths_absolute:
            img_filename = os.path.basename(img_path_abs)
            # Construct URL relative to the static folder root
            img_url_relative = os.path.join(output_dir_relative, img_filename).replace("\\", "/")
            # Use url_for to get the correct URL path
            img_url = url_for("static", filename=img_url_relative)
            image_urls.append(img_url)
            print(f"Generated URL: {img_url}")

        print(f"Conversion {conversion_id} finished. Found {len(image_urls)} images.")
        return render_template("results.html", image_urls=image_urls)

    except Exception as e:
        print(f"Error during conversion {conversion_id}: {e}")
        # Optionally, clean up the directory on error
        # shutil.rmtree(output_dir_absolute)
        return render_template("results.html", error=f"An error occurred: {e}", image_urls=[])

# Serve static files (like generated images)
# Flask does this automatically if static_folder is set correctly relative to app root
# but defining it explicitly can help clarity.
# @app.route("/outputs/<path:filename>")
# def serve_output_image(filename):
#     return send_from_directory(OUTPUT_BASE_DIR, filename)

if __name__ == "__main__":
    # Make sure NLTK data is downloaded before starting the app
    try:
        import story_processor
        story_processor.download_nltk_data()
    except Exception as e:
        print(f"Warning: Could not pre-download NLTK data: {e}")
        
    # Run the app on 0.0.0.0 to make it accessible externally
    app.run(host="0.0.0.0", port=5000, debug=True)

