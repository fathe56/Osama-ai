import nltk
import re

def download_nltk_data():
    """Downloads necessary NLTK data if not already present."""
    required_resources = [("tokenizers/punkt", "punkt"), 
                          ("taggers/averaged_perceptron_tagger", "averaged_perceptron_tagger"),
                          ("tokenizers/punkt_tab", "punkt_tab")]
    
    print("NLTK data check...")
    all_downloaded = True
    for resource_path, resource_id in required_resources:
        try:
            nltk.data.find(resource_path)
            print(f"NLTK resource ", end="") # Use end="" to avoid newline
            print(f"'{resource_id}' already downloaded.")
        except LookupError:
            all_downloaded = False
            print(f"Downloading NLTK {resource_id}...")
            try:
                nltk.download(resource_id, quiet=True)
                print(f"Downloaded NLTK {resource_id}.")
            except Exception as e:
                print(f"Error downloading NLTK {resource_id}: {e}")
                # Decide if this is critical or if we can proceed
                # For now, let's assume punkt and averaged_perceptron_tagger are critical
                if resource_id in ["punkt", "averaged_perceptron_tagger", "punkt_tab"]:
                    raise # Re-raise the exception if critical data failed
    if all_downloaded:
        print("NLTK data check complete.")

def analyze_scene(scene_text: str):
    """Analyzes a scene text to extract basic information (e.g., characters, actions - placeholder)."""
    # Basic analysis: just return the text for now
    # In a more advanced version, this would extract characters, actions, setting details
    # Explicitly specify Arabic for sentence tokenization
    try:
        sentences = nltk.sent_tokenize(scene_text, language='arabic')
    except Exception as e:
        print(f"Error tokenizing scene: {e}. Falling back to simple split.")
        # Fallback: split by newline if tokenization fails
        sentences = [s.strip() for s in scene_text.split("\n") if s.strip()]
        if not sentences:
             sentences = [scene_text] # Use the whole text if split fails
             
    # Placeholder for more complex analysis
    analysis = {
        "text": scene_text,
        "sentences": sentences,
        "characters": [], # Placeholder
        "actions": [],    # Placeholder
        "setting": ""     # Placeholder
    }
    return analysis

def segment_story_into_scenes(story_text: str):
    """Segments the story into potential scenes based on paragraphs or explicit markers."""
    # Simple segmentation based on double newlines (paragraphs)
    # More sophisticated methods could use scene markers or NLP techniques
    scenes = [p.strip() for p in story_text.strip().split("\n\n") if p.strip()]
    if not scenes:
        # If no double newlines, treat the whole story as one scene
        scenes = [story_text.strip()] 
    print(f"Segmented into {len(scenes)} potential scenes.")
    return scenes

def process_story(story_text: str):
    """Processes the entire story: segments into scenes and analyzes each scene."""
    # Ensure NLTK data is available
    download_nltk_data()
    
    scenes = segment_story_into_scenes(story_text)
    analyzed_scenes = []
    for i, scene in enumerate(scenes):
        print(f"Processing Scene {i+1}/{len(scenes)}...")
        analysis = analyze_scene(scene)
        analyzed_scenes.append(analysis)
    print("Story processing complete.")
    return analyzed_scenes

# Example Usage (for testing the module itself)
if __name__ == "__main__":
    sample_story_text = """
كان يا مكان في قديم الزمان، قرية صغيرة تقع بجانب غابة كثيفة. عاش في القرية فتى شجاع اسمه "علي". كان علي يحب استكشاف الغابة.

في أحد الأيام، بينما كان علي يتجول في الغابة، سمع صوتًا غريبًا. قال لنفسه: "ما هذا الصوت؟". تبع علي الصوت بحذر حتى وصل إلى كهف مظلم.

"هل من أحد هنا؟" صاح علي بصوت مرتفع. خرج من الكهف تنين صغير لطيف بدا خائفًا. ابتسم علي وقال: "لا تخف أيها الصغير، أنا صديق".
    """
    
    print("Testing story processor...")
    processed_story = process_story(sample_story_text)
    
    if processed_story:
        print(f"\nSuccessfully processed story into {len(processed_story)} scenes.")
        # for i, scene_data in enumerate(processed_story):
        #     print(f"\nScene {i+1} Analysis:")
        #     print(f"  Text: {scene_data['text'][:100]}...") # Print first 100 chars
        #     print(f"  Sentences: {len(scene_data['sentences'])}")
    else:
        print("\nStory processing failed.")

